CREACION

POST index_key/_doc/
{
  "identSerialNum": "861237722",
  "consent": "S",
  "signerAlias": "",
  "vaultNameRec": "REDEBAN",
  "acctInfo": {
    "acctType": "CAHO",
    "acctId": "000000000000",
    "bankId": "0002"
  },
  "custInf": {
    "custFirstName": "VALENTINA",
    "custSecondName": "MARIA",
    "custFirstLastName": "ALVAREZ",
    "custSecondLastName": "CONTRERAS",
    "custLegalName": "",
    "custIdent": {
      "custIdentType": "CC",
      "custIdentNum": "123456"
    }
  },
  "statusKey": "ACTIVA",
  "sk": "4@VALENTINA0587",
  "custType": "PN",
  "id": "4@VALENTINA0587",
  "preferredIndicator": "N",
  "key": {
    "keyType": "4",
    "keyId": "@VALENTINA0587"
  },
  "effDtCreate": "2025-01-09T22:36:32.168Z"
}

MODIFICACION
POST /index_key/_update/rLDPVZcBIgmGib4XP9-J
{
  "script": {
    "source": "ctx._source.statusKey = 'CANCELADA'",
    "lang": "painless"
  }
}

ACTUALIZACION CON PUT
PUT /index_key/_doc/nCXHVZcBnkFrIwBtSEHx


ELIMINACION
DELETE index_key/_doc/miWMVZcBnkFrIwBtxkE9

CONSULTA POR INDICE
GET /index_key/_doc/nCXHVZcBnkFrIwBtSEHx
